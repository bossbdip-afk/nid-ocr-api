/*
  Production: after Render deploy, replace the empty string below with your
  Render API URL, for example:
  window.PYTHON_API_BASE = "https://sbtechinfo-nid-ocr-api.onrender.com";

  For quick testing, api-setup.html can save a URL in this browser.
*/
window.PYTHON_API_BASE = "";
try {
  if (!window.PYTHON_API_BASE) {
    window.PYTHON_API_BASE = localStorage.getItem("SBTECHINFO_NID_API_BASE") || "";
  }
} catch (e) {}
