V13 - Render Deploy Pack (Python PyMuPDF + Bengali Visual OCR)
===============================================================

এই pack-এর উদ্দেশ্য:
- sbtechinfo.liveblog365.com-এ শুধু frontend থাকবে।
- Python OCR API Render-এ Docker web service হিসেবে চলবে।
- PDF browser থেকে Python API-তে যাবে, field অনুযায়ী clean JSON ফিরে আসবে।

PART A — Python API deploy (Render)
1. render_api_repo ফোল্ডারের সব ফাইল একটি GitHub repository-এর root-এ upload করুন।
2. Render dashboard -> New -> Blueprint নির্বাচন করুন।
3. GitHub repository connect করুন। Render root-এর render.yaml পড়বে।
4. Deploy Blueprint দিন।
5. Deploy শেষ হলে একটি URL পাবেন, যেমন:
   https://sbtechinfo-nid-ocr-api.onrender.com
6. ওই URL + /health খুলুন। JSON-এ ok:true এবং tesseract:true থাকা উচিত।

PART B — Frontend connect
1. frontend ফোল্ডারের সব ফাইল sbtechinfo.liveblog365.com-এর web root-এ upload/overwrite করুন।
2. browser-এ https://sbtechinfo.liveblog365.com/api-setup.html খুলুন।
3. Render URL paste করে Save & Test দিন।
4. Test OK হলে https://sbtechinfo.liveblog365.com/ খুলে PDF দিন।

PRODUCTION NOTE
- api-setup.html localStorage ব্যবহার করে, তাই quick test-এর জন্য।
- সব visitor-এর জন্য স্থায়ীভাবে API URL দিতে frontend/api-config.js-এ:
  window.PYTHON_API_BASE = "https://YOUR-RENDER-URL";
  বসিয়ে আবার upload করুন।

IMPORTANT
- ProFreeHost-এ Python API চলবে না; Render/VPS-এর মতো Python/Docker host লাগবে।
- Download PDF drawing/layout frontend থেকে আগের মতোই থাকে।
- Render free instance sleep/cold-start করলে প্রথম request কিছুটা দেরি হতে পারে।
